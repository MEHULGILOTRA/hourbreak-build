#!/bin/bash
PLIST="$HOME/Library/LaunchAgents/com.pranjul.hourbreak.plist"
launchctl unload "$PLIST" 2>/dev/null || true
rm -f "$PLIST"
pkill -x HourBreak 2>/dev/null || true
rm -rf /Applications/HourBreak.app
echo "HourBreak removed."
