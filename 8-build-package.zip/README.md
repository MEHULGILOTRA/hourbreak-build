# HourBreak 1.1.0

A personal macOS menu-bar app: after **60 minutes of continuous use**, the screen goes dark for **one minute**. It no longer fires at the top of each clock hour.

Press **Ctrl+Option+Cmd+B** during the dark minute to return early, or wait 60 seconds.

## What counts as a break

- **5 minutes without keyboard, mouse or trackpad input** resets the timer. Returning starts a new full hour, not the leftover minute from the previous session.
- Locking the Mac, changing to an inactive login session, display sleep or system sleep resets it too. Even a short lock/sleep starts fresh.
- Brief pauses under 5 minutes stay part of the same session.
- If the hour becomes due while there is no input, the blackout waits for activity. If inactivity reaches 5 minutes, that pending break is discarded and the timer resets.
- The dark minute itself is not counted toward the next hour. Returning early also starts a fresh hour.
- Quitting/relaunching starts a new hour. No old usage is saved.

**Limit:** this estimates continuous use from input activity and Mac sleep/lock signals. It cannot tell whether you are looking at the screen. Reading or watching video without any input for 5 minutes counts as a break too. Move the pointer occasionally to keep that session active, or lock the Mac when leaving for an immediate reset.

## Unchanged

- Half-moon menu-bar icon; no Dock icon.
- A 60-second countdown on every connected display.
- Ctrl+Option+Cmd+B is registered only during the dark minute.
- Menu: remaining continuous-use minutes, Take a Break Now, Quit.
- Starts automatically at login. No network connection needed by the app.

## Install or update

On this repository page choose **Code > Download ZIP**. Use the new ZIP, not a copy saved before this update. Extract it in Finder, open Terminal, type `cd ` (including the space), drag the extracted folder into Terminal and press Return. Then run:

```sh
bash install.sh
```

The installer builds the app with Xcode Command Line Tools, runs the timer regression tests, stops the old HourBreak, replaces `/Applications/HourBreak.app`, and starts it with the existing login setup. Build/test failures stop installation before the old app is changed.

The output should include `HourBreak timer tests passed (8 scenarios).`

To run the timing tests separately:

```sh
./HourBreak.app/Contents/MacOS/HourBreak --test
```

The tests cover the hour boundary, a 59-minute session followed by a real idle break, brief pauses, lock/sleep reset, a suspended process, excluding the dark minute, launch without activity and invalid idle data. The Mac UI, lock notifications and multi-display behavior still need testing on a Mac.

## Remove

```sh
bash uninstall.sh
```
