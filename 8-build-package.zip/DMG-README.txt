HourBreak 1.1.0 for Intel Macs, macOS 13 or later

INSTALL
Drag HourBreak.app to Applications, then open it from Applications.
Look for the half-circle icon in the menu bar. There is no Dock icon.
The app is ad-hoc signed, not Apple-notarized. macOS may require you to
approve this app in System Settings > Privacy & Security after first launch.
Do not disable Gatekeeper globally.

USE
After 60 minutes of continuous use, a black overlay displays a 60-second
countdown. This does not put the Mac to sleep or change lock settings.
Press Control + Option + Command + B to end the break early.
Use the menu to take a break now or quit.
Five minutes without input, or a lock/sleep, resets the hour. Reading or
video playback without input also counts as idle. No usage is saved.

LOGIN
Unlike the source repository's install.sh, drag-and-drop installation does
not create a login LaunchAgent or start the app automatically at login.
To opt in, use macOS System Settings > General > Login Items and add the
installed HourBreak.app. No login item is enabled by this DMG or app.

SOURCE
Private personal build of pranjulgilotra-del/hourbreak-personal,
commit 02da5ed79fcf21be31f250aacf8745e0adc26639.
Application source and Info.plist are unchanged.
Build and package verification is separate from real-device acceptance.
