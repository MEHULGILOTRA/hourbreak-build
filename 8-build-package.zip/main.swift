import Cocoa
import Carbon

// HourBreak 1.1.0 - one dark minute after an hour of continuous use.
// Press Ctrl+Option+Cmd+B during the dark minute to come back early.
// The hotkey is registered ONLY while the screen is dark, so it never
// clashes with shortcuts in other apps.


// Pure timing logic, separate from the Mac UI so it can be tested deterministically.
struct ContinuousSession {
    let useLimit: TimeInterval = 60 * 60
    let idleReset: TimeInterval = 5 * 60
    private(set) var startedAt: TimeInterval?
    private(set) var elapsed: TimeInterval = 0
    private var waitingSince: TimeInterval?
    private var previousInputAt: TimeInterval?
    private var previousSampleAt: TimeInterval?

    var remaining: TimeInterval { max(0, useLimit - elapsed) }

    mutating func reset(now: TimeInterval) {
        startedAt = nil
        elapsed = 0
        waitingSince = now
        previousInputAt = nil
        previousSampleAt = now
    }

    mutating func update(now: TimeInterval, idle: TimeInterval, available: Bool = true) -> Bool {
        guard available, now.isFinite, idle.isFinite, idle >= 0 else {
            reset(now: now)
            return false
        }
        if let previous = previousSampleAt, now < previous || now - previous >= idleReset {
            // A suspended process must not bring an old near-due hour back.
            reset(now: now)
        }
        previousSampleAt = now
        let inputAt = now - idle
        if idle >= idleReset {
            reset(now: now)
            previousInputAt = inputAt
            return false
        }
        if waitingSince == nil {
            // Do not count time from before the app launched.
            waitingSince = now
            if idle <= 1 { startedAt = now }
        }
        if let previous = previousInputAt, inputAt - previous >= idleReset {
            // Also catch a full idle gap if the next sample is after new input.
            startedAt = max(inputAt, waitingSince ?? inputAt)
        }
        previousInputAt = max(previousInputAt ?? inputAt, inputAt)
        if startedAt == nil, inputAt >= (waitingSince ?? now) {
            startedAt = inputAt
        }
        if let start = startedAt {
            elapsed = max(0, now - start)
        } else {
            elapsed = 0
        }
        // If the hour becomes due while away, wait for activity. This gives
        // a real idle break time to reset instead of showing a blackout to nobody.
        return elapsed >= useLimit && idle < 2
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {

    private var statusItem: NSStatusItem!
    private var nextBreakItem: NSMenuItem!
    private var overlays: [NSWindow] = []
    private var countdownLabels: [NSTextField] = []
    private var hotKeyRef: EventHotKeyRef?
    private var session = ContinuousSession()
    private var activityTimer: Timer?
    private var unavailableReasons = Set<String>()
    private var observers: [NSObjectProtocol] = []
    private var distributedObservers: [NSObjectProtocol] = []
    private var countdownTimer: Timer?
    private var dismissWork: DispatchWorkItem?

    private static let breakSeconds = 60
    private static let hotKeySignature: OSType = 0x4842524B // 'HBRK'
    // Carbon key codes: ANSI "B" = 0x0B; controlKey (0x1000) | optionKey (0x0800) | cmdKey (0x0100) = 0x1900.
    private static let hotKeyCode: UInt32 = 0x0B
    private static let hotKeyModifiers: UInt32 = 0x1900

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.accessory) // menu-bar app, no Dock icon
        installHotKeyHandler()
        setupStatusItem()
        observeAvailability()
        let timer = Timer(timeInterval: 1, repeats: true) { [weak self] _ in
            self?.checkActivity()
        }
        RunLoop.main.add(timer, forMode: .common)
        activityTimer = timer
        checkActivity()
    }

    // MARK: - Menu bar

    private func setupStatusItem() {
        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.title = "\u{25D0}" // circle with left half black

        let menu = NSMenu()
        nextBreakItem = NSMenuItem(title: "", action: nil, keyEquivalent: "")
        nextBreakItem.isEnabled = false
        menu.addItem(nextBreakItem)
        menu.addItem(.separator())

        let now = NSMenuItem(title: "Take a Break Now", action: #selector(startBreakNow), keyEquivalent: "")
        now.target = self
        menu.addItem(now)
        menu.addItem(.separator())

        let quit = NSMenuItem(title: "Quit HourBreak", action: #selector(quitApp), keyEquivalent: "q")
        quit.target = self
        menu.addItem(quit)

        statusItem.menu = menu
        refreshNextBreakTitle()
    }

    private func refreshNextBreakTitle() {
        if !overlays.isEmpty {
            nextBreakItem.title = "Break in progress"
        } else if session.startedAt == nil {
            nextBreakItem.title = "Timer reset. Waiting for activity"
        } else {
            let minutes = Int(ceil(session.remaining / 60))
            nextBreakItem.title = "Next break in \(minutes) min of continuous use"
        }
    }

    @objc private func quitApp() {
        NSApp.terminate(nil)
    }

    // MARK: - Continuous-use scheduling

    private func checkActivity() {
        let now = ProcessInfo.processInfo.systemUptime
        // Use the most recent real input event, not CGEventType.null.
        let inputTypes: [CGEventType] = [
            .keyDown, .keyUp, .flagsChanged, .mouseMoved,
            .leftMouseDown, .leftMouseUp, .rightMouseDown, .rightMouseUp,
            .leftMouseDragged, .rightMouseDragged, .scrollWheel,
            .otherMouseDown, .otherMouseUp, .otherMouseDragged,
            .tabletPointer, .tabletProximity
        ]
        let idle = inputTypes.map {
            CGEventSource.secondsSinceLastEventType(.combinedSessionState, eventType: $0)
        }.min() ?? .infinity
        let due = session.update(now: now, idle: idle,
                                 available: unavailableReasons.isEmpty && overlays.isEmpty)
        if due { beginBreak() }
        refreshNextBreakTitle()
    }

    private func setUnavailable(_ reason: String, _ unavailable: Bool) {
        if unavailable { unavailableReasons.insert(reason) }
        else { unavailableReasons.remove(reason) }
        session.reset(now: ProcessInfo.processInfo.systemUptime)
        // Never leave stale black windows over the login/wake screen.
        if unavailable && !overlays.isEmpty { endBreak() }
        refreshNextBreakTitle()
    }

    private func observeAvailability() {
        let center = NSWorkspace.shared.notificationCenter
        let pairs: [(Notification.Name, Notification.Name, String)] = [
            (NSWorkspace.willSleepNotification, NSWorkspace.didWakeNotification, "sleep"),
            (NSWorkspace.screensDidSleepNotification, NSWorkspace.screensDidWakeNotification, "display"),
            (NSWorkspace.sessionDidResignActiveNotification,
             NSWorkspace.sessionDidBecomeActiveNotification, "session")
        ]
        for (off, on, reason) in pairs {
            observers.append(center.addObserver(forName: off, object: nil, queue: .main) { [weak self] _ in
                self?.setUnavailable(reason, true)
            })
            observers.append(center.addObserver(forName: on, object: nil, queue: .main) { [weak self] _ in
                self?.setUnavailable(reason, false)
            })
        }
        // Supplemental lock notifications. Sleep and idle checks still work
        // if a macOS release does not send these distributed notifications.
        let distributed = DistributedNotificationCenter.default()
        for (name, locked) in [("com.apple.screenIsLocked", true),
                               ("com.apple.screenIsUnlocked", false)] {
            distributedObservers.append(distributed.addObserver(
                forName: Notification.Name(name), object: nil, queue: .main) { [weak self] _ in
                    self?.setUnavailable("lock", locked)
                })
        }
    }

    @objc private func startBreakNow() {
        beginBreak()
    }

    // MARK: - Break

    private func beginBreak() {
        guard overlays.isEmpty else { return }
        showOverlays()
        registerHotKey()
        let work = DispatchWorkItem { [weak self] in self?.endBreak() }
        dismissWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(AppDelegate.breakSeconds), execute: work)
        session.reset(now: ProcessInfo.processInfo.systemUptime)
        refreshNextBreakTitle()
    }

    @objc private func endBreakEarly() {
        endBreak()
    }

    private func endBreak() {
        session.reset(now: ProcessInfo.processInfo.systemUptime)
        dismissWork?.cancel()
        dismissWork = nil
        countdownTimer?.invalidate()
        countdownTimer = nil
        unregisterHotKey()
        let windows = overlays
        overlays.removeAll()
        countdownLabels.removeAll()
        refreshNextBreakTitle()
        NSAnimationContext.runAnimationGroup({ ctx in
            ctx.duration = 0.4
            windows.forEach { $0.animator().alphaValue = 0 }
        }, completionHandler: {
            windows.forEach { $0.orderOut(nil); $0.close() }
        })
    }

    private func showOverlays() {
        countdownLabels.removeAll()
        for screen in NSScreen.screens {
            let window = NSWindow(contentRect: screen.frame,
                                  styleMask: .borderless,
                                  backing: .buffered,
                                  defer: false)
            window.level = NSWindow.Level(rawValue: Int(CGShieldingWindowLevel()))
            window.isOpaque = true
            window.backgroundColor = .black
            window.hasShadow = false
            window.isReleasedWhenClosed = false
            window.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]

            let content = NSView(frame: NSRect(origin: .zero, size: screen.frame.size))

            let number = NSTextField(labelWithString: String(AppDelegate.breakSeconds))
            number.font = NSFont.monospacedDigitSystemFont(ofSize: 120, weight: .ultraLight)
            number.textColor = NSColor.white.withAlphaComponent(0.85)
            number.alignment = .center
            number.translatesAutoresizingMaskIntoConstraints = false

            let hint = NSTextField(labelWithString: "HourBreak: press \u{2303}\u{2325}\u{2318}B to return early")
            hint.font = NSFont.systemFont(ofSize: 16, weight: .light)
            hint.textColor = NSColor.white.withAlphaComponent(0.5)
            hint.alignment = .center
            hint.translatesAutoresizingMaskIntoConstraints = false

            content.addSubview(number)
            content.addSubview(hint)
            NSLayoutConstraint.activate([
                number.centerXAnchor.constraint(equalTo: content.centerXAnchor),
                number.centerYAnchor.constraint(equalTo: content.centerYAnchor),
                hint.centerXAnchor.constraint(equalTo: content.centerXAnchor),
                hint.topAnchor.constraint(equalTo: number.bottomAnchor, constant: 12),
            ])

            window.contentView = content
            window.alphaValue = 0
            window.orderFrontRegardless()
            NSAnimationContext.runAnimationGroup { ctx in
                ctx.duration = 0.4
                window.animator().alphaValue = 1
            }
            overlays.append(window)
            countdownLabels.append(number)
        }

        var remaining = AppDelegate.breakSeconds
        countdownTimer?.invalidate()
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] timer in
            guard let self = self else { timer.invalidate(); return }
            remaining -= 1
            if remaining <= 0 {
                timer.invalidate()
                remaining = 0
            }
            let text = String(remaining)
            self.countdownLabels.forEach { $0.stringValue = text }
        }
    }

    // MARK: - Global hotkey (Carbon), registered only while the screen is dark

    private func installHotKeyHandler() {
        var spec = EventTypeSpec(eventClass: OSType(kEventClassKeyboard),
                                 eventKind: UInt32(kEventHotKeyPressed))
        let selfPtr = Unmanaged.passUnretained(self).toOpaque()
        InstallEventHandler(GetApplicationEventTarget(), { (_, _, userInfo) -> OSStatus in
            guard let userInfo = userInfo else { return noErr }
            let app = Unmanaged<AppDelegate>.fromOpaque(userInfo).takeUnretainedValue()
            DispatchQueue.main.async { app.endBreakEarly() }
            return noErr
        }, 1, &spec, selfPtr, nil)
    }

    private func registerHotKey() {
        unregisterHotKey()
        let hotKeyID = EventHotKeyID(signature: AppDelegate.hotKeySignature, id: 1)
        RegisterEventHotKey(AppDelegate.hotKeyCode,
                            AppDelegate.hotKeyModifiers,
                            hotKeyID,
                            GetApplicationEventTarget(),
                            0,
                            &hotKeyRef)
    }

    private func unregisterHotKey() {
        if let ref = hotKeyRef {
            UnregisterEventHotKey(ref)
            hotKeyRef = nil
        }
    }
}

func runTimerTests() {
    // Deterministic regression tests. Run the built app with --test.
    func expect(_ condition: @autoclosure () -> Bool, _ message: String) {
        precondition(condition(), message)
    }
    func use(_ timer: inout ContinuousSession, from: Int, through: Int) -> Bool {
        var due = false
        for t in from...through { due = timer.update(now: Double(t), idle: 0) }
        return due
    }
    
    var regular = ContinuousSession()
    expect(!use(&regular, from: 1000, through: 4599), "Must not fire before one hour")
    expect(regular.update(now: 4600, idle: 0), "Must fire at 60 continuous minutes")
    
    var idleBreak = ContinuousSession()
    _ = use(&idleBreak, from: 1000, through: 4540) // 59 minutes
    for t in 4541...4840 {
        expect(!idleBreak.update(now: Double(t), idle: Double(t - 4540)), "No blackout while away")
    }
    expect(idleBreak.startedAt == nil, "Five idle minutes must clear the old hour")
    expect(!idleBreak.update(now: 4841, idle: 0), "Return after a real break starts fresh")
    expect(!use(&idleBreak, from: 4842, through: 4901), "Must not fire one minute after return")
    expect(!use(&idleBreak, from: 4902, through: 8440), "Fresh hour must run in full")
    expect(idleBreak.update(now: 8441, idle: 0), "New hour must fire when complete")
    
    var shortPause = ContinuousSession()
    _ = use(&shortPause, from: 1000, through: 2800)
    for t in 2801...2920 { _ = shortPause.update(now: Double(t), idle: Double(t - 2800)) }
    expect(!shortPause.update(now: 2921, idle: 0), "Short pause must not fire early")
    expect(shortPause.startedAt == 1000, "Two-minute pause must not reset")
    expect(use(&shortPause, from: 2922, through: 4600), "Short pauses count in the continuous session")
    
    var locked = ContinuousSession()
    _ = use(&locked, from: 1000, through: 4540)
    expect(!locked.update(now: 4541, idle: 0, available: false), "Lock/sleep must not trigger")
    expect(!locked.update(now: 4550, idle: 0), "Even a short lock starts a fresh hour")
    expect(!use(&locked, from: 4551, through: 4610), "No break one minute after unlock")
    
    var suspended = ContinuousSession()
    _ = use(&suspended, from: 1000, through: 4540)
    expect(!suspended.update(now: 5000, idle: 0), "Suspension gap must discard the old hour")
    expect(suspended.startedAt == 5000, "Suspension resumes with a fresh session")
    
    var blackout = ContinuousSession()
    _ = use(&blackout, from: 1000, through: 4600)
    blackout.reset(now: 4600)
    for t in 4601...4660 { _ = blackout.update(now: Double(t), idle: 0, available: false) }
    expect(!blackout.update(now: 4661, idle: 0), "Blackout must not count toward next hour")
    expect(blackout.startedAt == 4661, "Fresh hour begins after blackout")
    
    var delayedLaunch = ContinuousSession()
    expect(!delayedLaunch.update(now: 1000, idle: 100), "Launch must not count prelaunch use")
    expect(delayedLaunch.startedAt == nil, "Wait for first activity on launch")
    expect(!delayedLaunch.update(now: 1001, idle: 0), "First activity starts new hour")
    expect(delayedLaunch.startedAt == 1001, "First activity timestamp")
    
    var invalid = ContinuousSession()
    expect(!invalid.update(now: 1000, idle: .infinity), "Invalid idle must fail safely")
    expect(!invalid.update(now: 1001, idle: 0), "Recover safely after invalid idle")
    print("HourBreak timer tests passed (8 scenarios).")
}

if CommandLine.arguments.contains("--test") {
    runTimerTests()
} else {
    let app = NSApplication.shared
    let delegate = AppDelegate()
    app.delegate = delegate
    // Keep a strong reference while NSApplication holds its weak delegate.
    withExtendedLifetime(delegate) {
        app.run()
    }
}
