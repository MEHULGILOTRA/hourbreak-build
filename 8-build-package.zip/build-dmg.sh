#!/bin/bash
# Build only. Does not install, stop apps, or enable login items.
set -euo pipefail
cd "$(dirname "$0")"
ROOT="$PWD"
OUT="$ROOT/out"
APP="$OUT/HourBreak.app"
mkdir -p "$APP/Contents/MacOS"
cp Info.plist "$APP/Contents/Info.plist"
echo '[20%] Compiling Intel macOS app; total build usually under 3 minutes.'
swiftc -Onone -target x86_64-apple-macos13.0 -o "$APP/Contents/MacOS/HourBreak" main.swift -framework Cocoa -framework Carbon
printf '[45%%] Running original eight timer regression scenarios.\n'
"$APP/Contents/MacOS/HourBreak" --test
codesign --force --sign - "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"
file "$APP/Contents/MacOS/HourBreak"
lipo -verify_arch x86_64 "$APP/Contents/MacOS/HourBreak"
plutil -lint "$APP/Contents/Info.plist"
echo '[60%] Creating drag-to-Applications disk image.'
mkdir -p "$OUT/staging"
ditto "$APP" "$OUT/staging/HourBreak.app"
ln -s /Applications "$OUT/staging/Applications"
cp DMG-README.txt "$OUT/staging/READ ME.txt"
hdiutil create -volname 'HourBreak 1.1.0' -srcfolder "$OUT/staging" -ov -format UDZO "$OUT/HourBreak-1.1.0-Intel.dmg"
hdiutil verify "$OUT/HourBreak-1.1.0-Intel.dmg"
echo '[80%] Verifying app inside actual disk image.'
MOUNT="$OUT/verify-mount"
mkdir -p "$MOUNT"
hdiutil attach "$OUT/HourBreak-1.1.0-Intel.dmg" -nobrowse -readonly -mountpoint "$MOUNT"
trap 'hdiutil detach "$MOUNT" || true' EXIT
cmp "$APP/Contents/MacOS/HourBreak" "$MOUNT/HourBreak.app/Contents/MacOS/HourBreak"
codesign --verify --deep --strict "$MOUNT/HourBreak.app"
"$MOUNT/HourBreak.app/Contents/MacOS/HourBreak" --test
hdiutil detach "$MOUNT"
trap - EXIT
shasum -a 256 "$OUT/HourBreak-1.1.0-Intel.dmg" > "$OUT/SHA256.txt"
echo '[100%] DMG build and package checks passed. Interactive device behavior is a separate check.'
