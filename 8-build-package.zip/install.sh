#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
APP="HourBreak.app"
DEST="/Applications/$APP"

echo "Building HourBreak (needs Xcode Command Line Tools)..."
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS"
cp Info.plist "$APP/Contents/Info.plist"
swiftc -O -o "$APP/Contents/MacOS/HourBreak" main.swift -framework Cocoa -framework Carbon
echo "Checking HourBreak 1.1.0 timer tests..."
"$APP/Contents/MacOS/HourBreak" --test
xattr -cr "$APP"
codesign --force --sign - "$APP"

echo "Stopping the previous HourBreak..."
launchctl unload "$HOME/Library/LaunchAgents/com.pranjul.hourbreak.plist" 2>/dev/null || true
pkill -x HourBreak || true

echo "Installing to /Applications..."
rm -rf "$DEST"
ditto --noextattr --norsrc "$APP" "$DEST"

echo "Setting up start at login..."
PLIST="$HOME/Library/LaunchAgents/com.pranjul.hourbreak.plist"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.pranjul.hourbreak</string>
    <key>ProgramArguments</key>
    <array>
        <string>$DEST/Contents/MacOS/HourBreak</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
</dict>
</plist>
EOF
launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"

echo ""
echo "Done. HourBreak is running now and will start at every login."
echo "Look for the half-moon icon in the menu bar (top right)."
echo "Break: after 60 minutes of continuous use, screen dark for 60 seconds."
echo "Press Ctrl+Option+Cmd+B during the dark minute to come back early."
echo "Timer resets after 5 minutes without input, or on lock/display sleep/system sleep."
echo "No-input reading or video for 5 minutes also resets it."
